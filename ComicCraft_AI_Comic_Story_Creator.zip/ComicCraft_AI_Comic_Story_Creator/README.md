# ComicCraft — AI Comic Story Creator using Gemini Models

A complete educational full-stack project that turns a story idea into an original comic script using Google's Gemini API.

## Features
- Genre, tone, audience and language controls
- Character and setting inputs
- 3–12 comic panels
- Gemini-generated title, logline, characters, scenes, dialogue and visual prompts
- Responsive comic-style UI
- Demo fallback when no API key is configured
- FastAPI REST API and automatic `/docs`
- No user account or persistent storage

## Setup
Python 3.10+ is recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

Copy `.env.example` to `.env`, add your Gemini API key, then:

```bash
uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000`.

Without a Gemini key, the app runs in demo fallback mode. For real AI output, configure `GEMINI_API_KEY`.

## API
`POST /api/generate-comic`

Example:
```json
{
  "title":"The Clockwork Secret",
  "genre":"Adventure",
  "tone":"Fun and light",
  "audience":"Teen",
  "setting":"A modern city",
  "characters":"Two curious friends",
  "premise":"Two friends discover a tiny machine that predicts tomorrow.",
  "panels":6,
  "language":"English"
}
```

## Project structure
```text
ComicCraft_AI_Comic_Story_Creator/
├── app/
│   ├── main.py
│   ├── ai_service.py
│   └── static/
│       ├── index.html
│       ├── styles.css
│       └── app.js
├── requirements.txt
├── .env.example
├── .gitignore
└── README.md
```

## Important
This prototype generates text/script content and visual prompts; it does not generate actual comic artwork. An image-generation provider can be added later using each panel's `visual_prompt`. AI output should be reviewed before publication.
