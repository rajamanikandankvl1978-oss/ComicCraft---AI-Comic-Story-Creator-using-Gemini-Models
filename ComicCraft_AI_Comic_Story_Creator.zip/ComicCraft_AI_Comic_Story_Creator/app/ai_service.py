import os, json
from google import genai

def fallback(data):
    n=data["panels"]
    chars=data["characters"]
    panels=[]
    for i in range(1,n+1):
        if i==1:
            scene=f"Establish {data['setting']} and introduce {chars}."
            dialogue="Something unexpected is about to happen!"
        elif i==n:
            scene="The characters solve the immediate problem and end on an upbeat note."
            dialogue="That was quite a story!"
        else:
            scene=f"Panel {i}: The characters follow a clue and face a small challenge."
            dialogue="Let's keep going!"
        panels.append({"panel":i,"scene":scene,"visual_prompt":f"Comic panel, {data['genre']} style, {scene}","dialogue":[{"character":"Narrator","text":dialogue}]})
    return {
        "title": data["title"] or "ComicCraft Demo Story",
        "logline": data["premise"],
        "characters": [{"name":"Main character","description":chars}],
        "panels": panels,
        "ending":"A satisfying, positive ending with room for another episode.",
        "generation_mode":"Demo fallback — configure GEMINI_API_KEY for Gemini-generated stories."
    }

def generate_comic(data):
    key=os.getenv("GEMINI_API_KEY","").strip()
    if not key:
        return fallback(data)

    prompt=f"""
You are ComicCraft, an expert comic scriptwriter. Create an original comic story from these inputs:
{json.dumps(data, ensure_ascii=False)}
Return ONLY valid JSON with exactly these keys:
title, logline, characters, panels, ending.
characters: array of objects with name and description.
panels: exactly {data['panels']} objects, each with panel, scene, visual_prompt, dialogue.
dialogue must be an array of objects with character and text.
Make the story coherent from panel to panel, visually clear, age-appropriate, and original.
Do not copy or imitate a living artist's distinctive style. Keep dialogue concise enough for comic balloons.
If language is not English, write all story text in the requested language.
"""
    try:
        client=genai.Client(api_key=key)
        resp=client.models.generate_content(
            model=os.getenv("GEMINI_MODEL","gemini-2.5-flash"),
            contents=prompt,
            config={"response_mime_type":"application/json"}
        )
        result=json.loads(resp.text)
        result["generation_mode"]="Gemini AI"
        return result
    except Exception as exc:
        raise RuntimeError("Gemini could not generate the comic. Check GEMINI_API_KEY, GEMINI_MODEL, and your internet connection.") from exc
