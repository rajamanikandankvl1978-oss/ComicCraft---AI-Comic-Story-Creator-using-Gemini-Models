import os, json
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from dotenv import load_dotenv
from .ai_service import generate_comic

load_dotenv()
BASE_DIR=Path(__file__).resolve().parent
app=FastAPI(title="ComicCraft - AI Comic Story Creator", version="1.0.0")
app.mount("/static", StaticFiles(directory=BASE_DIR/"static"), name="static")

class ComicRequest(BaseModel):
    title: str = Field(default="", max_length=120)
    genre: str = "Adventure"
    tone: str = "Fun and light"
    audience: str = "Teen"
    setting: str = "A modern city"
    characters: str = Field(default="Two friends", max_length=1000)
    premise: str = Field(min_length=5, max_length=2000)
    panels: int = Field(default=6, ge=3, le=12)
    language: str = "English"

@app.get("/", response_class=HTMLResponse)
def home():
    return (BASE_DIR/"static"/"index.html").read_text(encoding="utf-8")

@app.get("/api/health")
def health():
    return {"status":"ok","service":"ComicCraft"}

@app.post("/api/generate-comic")
def create_comic(payload: ComicRequest):
    try:
        return generate_comic(payload.model_dump())
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail="Comic generation failed. Please try again.")
