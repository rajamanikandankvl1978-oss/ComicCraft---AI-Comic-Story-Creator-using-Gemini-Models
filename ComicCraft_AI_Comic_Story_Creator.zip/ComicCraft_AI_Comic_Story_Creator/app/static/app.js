const form=document.getElementById('comic-form'), out=document.getElementById('output'), go=document.getElementById('go');
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function render(c){
 let panels=(c.panels||[]).map(p=>`<article class="comicpanel"><div class="num">PANEL ${esc(p.panel)}</div><div class="scene">${esc(p.scene)}</div>${(p.dialogue||[]).map(d=>`<div class="balloon"><b>${esc(d.character)}:</b> ${esc(d.text)}</div>`).join('')}<div class="visual"><b>Visual:</b> ${esc(p.visual_prompt)}</div></article>`).join('');
 out.innerHTML=`<p class="eyebrow">YOUR COMIC</p><h2>${esc(c.title)}</h2><p class="muted">${esc(c.logline)}</p><h3>Characters</h3><ul>${(c.characters||[]).map(x=>`<li><b>${esc(x.name)}</b> — ${esc(x.description)}</li>`).join('')}</ul><h3>Comic panels</h3><div class="panelgrid">${panels}</div><h3>Ending</h3><p class="muted">${esc(c.ending)}</p><p class="muted"><small>${esc(c.generation_mode)}</small></p><button id="again">Create another comic ↻</button>`;
 out.classList.remove('hidden'); document.getElementById('again').onclick=()=>form.scrollIntoView({behavior:'smooth'});
}
form.onsubmit=async e=>{
 e.preventDefault();go.disabled=true;go.textContent='Creating your comic…';out.classList.remove('hidden');out.innerHTML='<p>Writing characters, scenes and dialogue…</p>';
 const d=Object.fromEntries(new FormData(form).entries());d.panels=Number(d.panels);
 try{const r=await fetch('/api/generate-comic',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});const x=await r.json();if(!r.ok)throw Error(x.detail||'Generation failed');render(x);out.scrollIntoView({behavior:'smooth'})}
 catch(x){out.innerHTML=`<p style="color:#ff9b9b">${esc(x.message)}</p>`}
 finally{go.disabled=false;go.innerHTML='Create my comic <b>→</b>'}
};
